# Todo-App
A quite simple Todo list app made with vanilla javascript

In the near future, I would like to
- [ ] Add a timing mechanism i.e let the user add a time frame for the task
- [ ] Notify the user with an alert and sound when time for a task approaches or expires 
- [ ] Take this stuff offline, more like a PWA 

 :simple_smile:
